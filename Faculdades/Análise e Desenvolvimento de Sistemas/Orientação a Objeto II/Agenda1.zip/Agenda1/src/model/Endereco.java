package model;

public class Endereco {
    private int idEndereco;
    private String rua;
    private String bairro;
    private String numero;
    private String CEP;
    private boolean Cp;
    
    //Getters & Setters
    
    /***************************************************/
    public int getidEndereco(){
        return idEndereco;
    }
    public void setidEndereco(int idEndereco){
        this.idEndereco = idEndereco;
    }
    /***************************************************/
    public String getRua(){
        return rua;
    }
    public void setRua(String rua){
        this.rua = rua;
    }
    /***************************************************/
    public String getBairro(){
        return bairro;
    }
    public void setBairro(String bairro){
        this.bairro = bairro;
    }
    /***************************************************/
    public String getNumero(){
        return numero;
    }
    public void setNumero(String numero){
        this.numero = numero;
    }
    /***************************************************/
    public String getCEP(){
        return CEP;
    }
    public void setCEP(String CEP){
        this.CEP = CEP;
    }
    /***************************************************/
    public boolean isCp(){
        return Cp;
    }
    public void setCp(boolean Cp){
        this.Cp = Cp;
    }
    /***************************************************/
    
    //Método toString
    
    public String toString(){
        String retorno = "Rua:"+getRua();
               retorno+="\nBairro:"+getBairro();
               retorno+="\nNumero:"+getNumero();
               retorno+="\nCEP:"+getCEP();
               return retorno;
    }
    
}