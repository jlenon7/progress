package model;
public class Comunicacao {
    private int idComunicacao;
    private String celular;
    private String fixo;
    private boolean whatsapp;
    private String email;
    private String facebook;

    public void setIdComunicacao(int idComunicacao) {
        this.idComunicacao = idComunicacao;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public void setFixo(String fixo) {
        this.fixo = fixo;
    }

    public void setWhatsapp(boolean whatsapp) {
        this.whatsapp = whatsapp;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public int getIdComunicacao() {
        return idComunicacao;
    }

    public String getCelular() {
        return celular;
    }

    public String getFixo() {
        return fixo;
    }

    public boolean isWhatsapp() {
        return whatsapp;
    }

    public String getEmail() {
        return email;
    }

    public String getFacebook() {
        return facebook;
    }


    public String toString() {
        String retorno="Celular:"+getCelular();
        retorno+="\nFixo :"+getFixo();
        retorno+="\nE-mail :"+getEmail();
        retorno+="\nFacebook :"+getFacebook();
        return retorno;
                
    }
    
}
