package control;

import dao.EnderecoDAO;
import model.Endereco;

public class EnderecoControl {
    public boolean controleInsercao(Endereco ed){
        boolean retorno = false;
       if(ed.getNumero().equals("")) {
           retorno = false;
       }
       else {
           EnderecoDAO dao = new EnderecoDAO();
           if(dao.inserir(ed))
               retorno = true;
       }
       return retorno;
    }   
}