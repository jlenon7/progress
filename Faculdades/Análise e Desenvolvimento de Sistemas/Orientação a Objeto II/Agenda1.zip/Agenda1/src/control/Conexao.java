package control;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
   private Connection con =null;

   public Connection conectar() {
	   String servidor = "jdbc:mysql://localhost:3306/agenda";
	   String usuario = "root";
	   String senha = "bancodedados";
	   String driver = "com.mysql.jdbc.Driver";
	   try {
		   Class.forName(driver);
		   this.con = DriverManager.getConnection(servidor,
				   								  usuario,
				   								  senha);
		}catch(Exception e) {
		 System.out.println("Erro de conexao "+e.getMessage());
		   
	   }
	   return this.con;
   }
}
