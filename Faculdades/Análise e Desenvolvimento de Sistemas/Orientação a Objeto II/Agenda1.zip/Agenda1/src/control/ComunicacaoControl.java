package control;

import dao.ComunicacaoDAO;
import model.Comunicacao;

public class ComunicacaoControl {
    public boolean controleInsercao(Comunicacao c){
        boolean retorno=false;
       if(c.getCelular().equals("")) {
           retorno=false; 
       }
       else {
          ComunicacaoDAO dao = new ComunicacaoDAO();
          if(dao.inserir(c))
              retorno= true;
       }
       return retorno;
    }
}
