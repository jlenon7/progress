package dao;
import control.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import model.Endereco;

public class EnderecoDAO {
    Connection con = null;
    public EnderecoDAO() {
    this.con=new Conexao().conectar();
}
    public ResultSet listaGeral(){
        String sql = "select * from endereco";
        ResultSet res=null;
        try{
            Statement stm = this.con.createStatement();
            res = stm.executeQuery(sql);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
        return res;
    
    }
    public boolean inserir(Endereco ed){
        boolean retorno = false;
        String sql ="insert into endereco (rua,bairro,numero,CEP,Cp)"
              + " values (?,?,?,?,?)";
    try{
        PreparedStatement pre = this.con.prepareStatement(sql);
        pre.setString(1, ed.getRua());
        pre.setString(2, ed.getBairro());
        pre.setString(3, ed.getNumero());
        pre.setString(4, ed.getCEP());
        pre.setBoolean(5, ed.isCp());
        pre.execute();
        retorno=true;
      }catch(Exception e){
          retorno=false;
          System.out.print("Erro ao inserir endereço"+e.getMessage());
      }
      return retorno;
    }
    
}
