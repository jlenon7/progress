package dao;
import control.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import model.Comunicacao;
public class ComunicacaoDAO {
    Connection con = null;
    public ComunicacaoDAO() {
      this.con=new Conexao().conectar();
   }
    public ResultSet listaGeral(){
        String sql = "select * from comunicacao";
        ResultSet res=null;
        try{
            Statement stm = this.con.createStatement();
            res= stm.executeQuery(sql);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        return res;
    }
    public boolean inserir(Comunicacao c){
        boolean retorno=false;
      String sql ="insert into comunicacao (celular,email,whatsapp,facebook,fixo)"
              + " values (?,?,?,?,?)";
      try{
        PreparedStatement pre = this.con.prepareStatement(sql);
        pre.setString(1, c.getCelular());
        pre.setString(2,c.getEmail());
        pre.setBoolean(3, c.isWhatsapp());
        pre.setString(4,c.getFacebook());
        pre.setString(5,c.getFixo());
        pre.execute();
        retorno=true;
      }catch(Exception e){
          retorno=false;
          System.out.print("Erro ao inserir comunicação"+e.getMessage());
      }
      return retorno;
    }
}
