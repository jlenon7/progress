package Aula07;

import javax.swing.JOptionPane;

public class Questao2 {
	public static void main(String[] args) {
		//variaveis
		Q2Fatorial fat = new Q2Fatorial();
		int n;
		
		//entrada
		n = Integer.parseInt(JOptionPane.showInputDialog("Valor para calcular o fatorial:"));
		
		JOptionPane.showMessageDialog(null, "O fatorial de " + n + " é: " + fat.fatorial(n));
	}//fim do main
}//fim da classe
