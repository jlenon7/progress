package Aula07;

public class Q2Fatorial {
	public static int fatorial(int num) {
		//Inicio
		if(num == 1 || num == 0) {
			return (1);
		} else {
			return (num * fatorial(num - 1));
		}
	}//Fim da Função Fatorial
}//Fim da Classe
