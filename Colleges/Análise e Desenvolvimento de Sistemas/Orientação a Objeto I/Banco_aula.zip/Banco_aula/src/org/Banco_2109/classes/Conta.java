package org.Banco_2109.classes;

public class Conta implements Banco {
	String nome;
	String numeroConta;
	String numeroAgencia;
	double saldoAtual;
	double valor;
	
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNumeroConta() {
		return numeroConta;
	}
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}
	public String getNumeroAgencia() {
		return numeroAgencia;
	}
	public void setNumeroAgencia(String numeroAgencia) {
		this.numeroAgencia = numeroAgencia;
	}
	public double getSaldoAtual() {
		return saldoAtual;
	}
	public void setSaldoAtual(double saldoAtual) {
		this.saldoAtual = saldoAtual;
	}
	
	
	void mostrarSaldo() {
		System.out.println("\nSeu saldo atual é de: "+ getSaldoAtual());
	}
	
	public double depositar(double valor) {
		 this.saldoAtual = this.saldoAtual + valor;
		mostrarSaldo();
		return saldoAtual;
		
	}
	public double sacar(double valor) {
		this.saldoAtual = this.saldoAtual - valor;
		mostrarSaldo();
		return saldoAtual;
		
	}
	
}
