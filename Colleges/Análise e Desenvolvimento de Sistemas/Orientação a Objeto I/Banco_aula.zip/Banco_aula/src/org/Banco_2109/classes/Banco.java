package org.Banco_2109.classes;

public interface Banco {
	
	static final double saldo = 0;
	
	abstract double sacar(double valor);
	abstract double depositar(double valor);
	
}
