package org.Banco_2109.classes;

public class App {
	public static void main(String[] args) {
		Conta co = new Conta();
		co.setNome("José Costa");
		co.setNumeroConta("13545-22");
		co.setNumeroAgencia("544");
		
		
		System.out.println("\nNome: "+ co.getNome());
		System.out.println("\nNumero da Conta: " + co.getNumeroConta());
		System.out.println("\nNumero da agencia: "+ co.getNumeroAgencia());
		co.depositar(1500.00);
		co.depositar(2500.00);
		co.sacar(3000.00);
	}
}
	
